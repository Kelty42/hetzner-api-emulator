-- Adminer 4.8.1 PostgreSQL 15.9 (Debian 15.9-1.pgdg120+1) dump

INSERT INTO "ips" ("id", "server_id", "ip_address", "mask") VALUES
(2,	2,	'123.123.123.124',	'64'),
(1,	1,	'123.123.123.123',	'64'),
(3,	1,	'123.123.123.125',	'64');

INSERT INTO "servers" ("id", "user_id", "server_number", "server_name", "product", "server_ipv6_net", "dc", "traffic", "status", "cancelled", "paid_until", "server_ip", "reset", "rescue", "vnc", "windows", "plesk", "cpanel", "wol", "hot_swap", "linked_storagebox", "reservation_possible", "reserved", "cancellation_date", "cancellation_reason") VALUES
(2,	1,	421,	'server2',	'X5',	'2a01:f48:111:4221::',	'FSN1-DC10',	'2 TB',	'ready',	'f',	'2010-06-11 00:00:00+00',	'123.123.123.66',	't',	't',	't',	't',	't',	't',	't',	't',	12345,	'f',	'f',	NULL,	NULL),
(1,	1,	321,	'servertest1',	'DS 3000',	'2a01:f48:111:4221::',	'NBG1-DC1',	'5 TB',	'ready',	'f',	'2010-09-02 00:00:00+00',	'123.123.123.5',	't',	't',	't',	't',	't',	't',	't',	't',	12345,	'f',	'f',	NULL,	NULL);

INSERT INTO "users" ("id", "username", "password", "created_at") VALUES
(1,	'test',	'$2a$10$IYfTyYs6VgNRsBpXA/XomutQA/ebo0s8EWwZbpApUynsrwRdaLGS2',	'2024-11-21 18:47:32.490547+00'),
(2,	'test1',	'$2a$10$2.NSCMstiyJ5rA2QIBlDrOG3vyq1Wupqj3EYyg8LreKy7CX16Zy62',	'2024-11-22 20:13:04.848795+00');

-- 2024-12-01 12:13:43.250736+00
